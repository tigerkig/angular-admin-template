import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AllJobsRoutingModule } from './all-jobs-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AllJobsRoutingModule
  ]
})
export class AllJobsModule { }
