import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-estimates-view',
  templateUrl: './estimates-view.component.html',
  styleUrls: ['./estimates-view.component.css']
})
export class EstimatesViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
