import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activities-main',
  templateUrl: './activities-main.component.html',
  styleUrls: ['./activities-main.component.css']
})
export class ActivitiesMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
