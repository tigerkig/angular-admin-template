import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calls-incoming',
  templateUrl: './calls-incoming.component.html',
  styleUrls: ['./calls-incoming.component.css']
})
export class CallsIncomingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
