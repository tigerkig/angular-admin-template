import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calls-outgoing',
  templateUrl: './calls-outgoing.component.html',
  styleUrls: ['./calls-outgoing.component.css']
})
export class CallsOutgoingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
