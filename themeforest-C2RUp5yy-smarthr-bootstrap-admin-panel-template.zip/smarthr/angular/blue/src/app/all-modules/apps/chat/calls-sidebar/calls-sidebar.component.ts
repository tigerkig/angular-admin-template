import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calls-sidebar',
  templateUrl: './calls-sidebar.component.html',
  styleUrls: ['./calls-sidebar.component.css']
})
export class CallsSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
