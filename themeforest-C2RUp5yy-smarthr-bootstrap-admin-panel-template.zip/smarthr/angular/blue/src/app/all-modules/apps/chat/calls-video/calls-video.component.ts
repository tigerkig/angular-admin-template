import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calls-video',
  templateUrl: './calls-video.component.html',
  styleUrls: ['./calls-video.component.css']
})
export class CallsVideoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
