import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calls-voice',
  templateUrl: './calls-voice.component.html',
  styleUrls: ['./calls-voice.component.css']
})
export class CallsVoiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
