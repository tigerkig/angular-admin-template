import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attendance-employee',
  templateUrl: './attendance-employee.component.html',
  styleUrls: ['./attendance-employee.component.css']
})
export class AttendanceEmployeeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
