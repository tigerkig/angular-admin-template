import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-knowledgebase-view',
  templateUrl: './knowledgebase-view.component.html',
  styleUrls: ['./knowledgebase-view.component.css']
})
export class KnowledgebaseViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
