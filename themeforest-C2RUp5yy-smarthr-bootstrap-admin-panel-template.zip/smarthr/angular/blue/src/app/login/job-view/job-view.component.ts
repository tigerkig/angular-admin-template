import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-job-view',
  templateUrl: './job-view.component.html',
  styleUrls: ['./job-view.component.css']
})
export class JobViewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
